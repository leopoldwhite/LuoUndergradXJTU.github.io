import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision.datasets import MNIST, CIFAR10
from torchvision.transforms import ToTensor, Normalize, Compose, Lambda
from tqdm import tqdm

def generate_datasets(root="./temp/MNIST", device=torch.device("cpu")):
    ToDevice = Lambda(lambda x: x.to(device))
    transform = Compose([ToTensor(), ToDevice])
    train_dataset = MNIST(root=root, train=True, download=True, transform=transform)
    test_dataset = MNIST(root=root, train=False, download=True, transform=transform)

    return train_dataset, test_dataset

def generate_datasets_cifar10(root="./temp/CIFAR10", device=torch.device("cpu")):
    ToDevice = Lambda(lambda x: x.to(device))
    transform = Compose([ToTensor(), ToDevice])
    train_dataset = CIFAR10(root=root, train=True, download=True, transform=transform)
    test_dataset = CIFAR10(root=root, train=False, download=True, transform=transform)

    return train_dataset, test_dataset

# def cifar10_to_pt():
#     a, b = generate_datasets_cifar10(device=torch.device("cuda"))
#     train = []
#     labels = []
#     test = []
#     for image in tqdm(a):
#         train.append(image[0])
#         labels.append(torch.LongTensor([image[1]]))
#     train = torch.stack(train, dim=0)
#     labels = torch.stack(labels, dim=0)
#     print(train.shape)
#     print(labels.shape)
#     torch.save({"data": train, "labels": labels.squeeze()}, "train.pt")
#     labels = []
#     for image in tqdm(b):
#         test.append(image[0])
#         labels.append(torch.LongTensor([image[1]]))
#     test = torch.stack(test, dim=0)
#     labels = torch.stack(labels, dim=0)
#     print(test.shape)
#     print(labels.shape)
#     torch.save({"data": test, "labels": labels.squeeze()}, "test.pt")


# if __name__ == "__main__":

    # cifar10_to_pt()