import torch
from torch.utils.data import Dataset, DataLoader

class my_dataset(Dataset):
    def __init__(self):
        self.data = torch.randn(50000, 3, 28, 28)
        self.labels = torch.randn(50000)
        
    def __getitem__(self, index):
        return self.data[index], self.labels[index] # [3, 28, 28], [1]
    
    
    def __len__(self):
        return self.data.size(0)
        

dataset = my_dataset()
dataloader = DataLoader(dataset=dataset, batch_size=64, shuffle=True)
# [64, 2, 28, 28], [64]
for data, labels in dataloader:
    print(data.shape)
    print(labels.shape)
    break