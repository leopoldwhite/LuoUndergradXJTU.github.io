import torch
import numpy as np
from scipy import sparse
from gensim import corpora
from gensim import models
from gensim import utils
from torch_sparse import SparseTensor

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    values=torch.FloatTensor(sparse_mx.data)
    indice=torch.LongTensor(np.vstack((sparse_mx.row,sparse_mx.col)).astype(np.int64))
    shape=torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indice,values,shape)

def load_features(path="./data/"):

    class MyCorpus:
        def __iter__(self):
            for line in open(path+"doc.txt"):
                line=line.replace("\n","")
                line=[word for word in line.split()]
                yield line

    sentences=MyCorpus()
    model = models.Word2Vec(sentences=sentences,vector_size=300,min_count=1)

    doc_vec=[]
    for sentence in sentences:
        length=len(sentence)
        vector=[0]*300
        for word in sentence:
            vector+=model.wv[word]
        vector/=length
        doc_vec.append(vector)
    
    vocab=[]
    for line in open(path+"vocab.txt"):
        vocab.append(line.replace("\n",""))
    word_vec=[]
    for word in vocab:
        word_vec.append(model.wv[word])

    doc_tensor=torch.Tensor(np.array(doc_vec))
    word_tensor=torch.Tensor(np.array(word_vec))
    features=torch.concat((doc_tensor,word_tensor),dim=0)

    return features

def load_adj(path="./data/"):
    adj=sparse.load_npz("./data/graph.npz")
    #return sparse_mx_to_torch_sparse_tensor(adj)
    return SparseTensor.from_scipy(adj)

def load_label_idx(path="./data/"):
    raw=open(path+"train_split.txt")
    train_label_dict={}
    train_label=[]
    train_idx=[]
    test_label_dict={}
    test_label=[]
    test_idx=[]
    for line in raw:
        idx,status,label=line.split()
        idx,label=int(idx),int(label)
        if status=="train":
            train_idx.append(idx)
            train_label_dict[idx]=label
        else:
            test_idx.append(idx)
            test_label_dict[idx]=label

    for i in sorted(train_label_dict.keys()):
        train_label.append(train_label_dict[i])
    for i in sorted(test_label_dict.keys()):
        test_label.append(test_label_dict[i])

    train_label=torch.LongTensor(np.array(train_label))
    test_label=torch.LongTensor(np.array(test_label))
    labels=torch.concat((train_label,test_label),dim=0)

    train_idx=torch.LongTensor(np.array(train_idx))
    test_idx=torch.LongTensor(np.array(test_idx))

    return labels,train_idx,test_idx

def load_data(path="./data/",device='cpu'):
    adj=load_adj(path).to(device)
    features=load_features(path).to(device)
    labels,train_idx,test_idx=load_label_idx(path)
    labels=labels.to(device=device)
    train_idx=train_idx.to(device=device)
    test_idx=test_idx.to(device=device)
    return adj,features,labels,train_idx,test_idx
