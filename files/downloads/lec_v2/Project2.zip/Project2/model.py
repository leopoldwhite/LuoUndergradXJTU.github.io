from turtle import forward
import torch.nn.functional as F
from torch_geometric.nn import GCNConv,SAGEConv,GATConv
import torch

class GCN(torch.nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super().__init__()
        self.conv1=GCNConv(nfeat,nhid)
        self.conv2=GCNConv(nhid,nclass)
        self.dropout=dropout

    def forward(self,x,adj):
        x=F.relu(self.conv1(x,adj))
        x=F.dropout(x,p=self.dropout,training=self.training)
        x=self.conv2(x,adj)
        return F.log_softmax(x, dim=1)

class SAGE(torch.nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super().__init__()
        self.conv1=SAGEConv(nfeat,nhid)
        self.conv2=SAGEConv(nhid,nclass)
        self.dropout=dropout

    def forward(self,x,adj):
        x=F.relu(self.conv1(x,adj))
        x=F.dropout(x,p=self.dropout,training=self.training)
        x=self.conv2(x,adj)
        return F.log_softmax(x, dim=1)

class GAT(torch.nn.Module):
    def __init__(self, nfeat, nhid, nclass,dropout):
        super().__init__()
        self.conv1=GATConv(nfeat,nhid,heads=8,dropout=dropout)
        self.conv2=GATConv(nhid,nclass,dropout=dropout)

    def forward(self,x,adj):
        x=F.relu(self.conv1(x,adj))
        x=self.conv2(x,adj)
        return F.log_softmax(x, dim=1)