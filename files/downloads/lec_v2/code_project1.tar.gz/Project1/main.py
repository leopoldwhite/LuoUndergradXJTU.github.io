import torch
from torch import nn
from torch.utils.data import DataLoader
from utils import generate_datasets, generate_datasets_cifar10
from model import two_layer_mlp_classifier
from pathlib import Path
import numpy as np
from tqdm import tqdm
from sklearn.metrics import f1_score
from torch.utils.tensorboard import SummaryWriter
import logging


class Trainer:
    def __init__(
            self,
            batch_size: int = 128,
            epochs: int = 100,
            device: str = "cpu",
            hidden_dim: int = 64,
            model_dir="./records",
            model_name="exp0",
            lr=1e-4,
            weight_decay=1e-5,
            optimizer=torch.optim.Adam,
            lr_scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau,
            debug=True,
    ):
        # space is a kind of fool
        self.batch_size = batch_size
        self.epochs = epochs
        self.model_dir = Path.cwd() / "tmp" / model_dir / model_name
        self.tsb_dir = self.model_dir / "tsb_logs"
        self.tsb_dir.mkdir(exist_ok=True, parents=True)
        
        self.checkpoint_dir = self.model_dir / "checkpoints"

        self.device = torch.device(device)
        train_set, test_set = generate_datasets_cifar10(device=self.device)
        input_dim = train_set[0][0].shape[1] * train_set[0][0].shape[2] * train_set[0][0].shape[0]

        self.model = two_layer_mlp_classifier(input_dim=input_dim, hidden_dim=hidden_dim, num_classes=10).to(self.device)
        
        self.loss_func = nn.CrossEntropyLoss()

        self.lr = lr
        self.weight_decay = weight_decay
        self.opt = optimizer(self.model.parameters(), lr=lr, weight_decay=self.weight_decay)
        if lr_scheduler:
            self.lr_scheduler = lr_scheduler(self.opt, mode="min")
        else:
            self.lr_scheduler = None

        self.train_loader = DataLoader(dataset=train_set, batch_size=batch_size, shuffle=True)
        self.test_loader = DataLoader(dataset=test_set, batch_size=batch_size, shuffle=False)
        self.tsb_logger = SummaryWriter(
            log_dir=self.tsb_dir, comment=model_name)
        
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG if debug else logging.INFO)
        self.log_dir = self.model_dir / "logging"
        self.log_dir.mkdir(exist_ok=True, parents=True)
        self.log_file = self.log_dir / "mnist.log"
        self.log_file.touch(exist_ok=True)
        logging_handler = logging.FileHandler(self.log_file)
        logging_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(logging_handler)

        self.global_time_step = 0

    @torch.no_grad()
    def test(self):
        losses = []
        y_pred = []
        y_true = []
        with tqdm(self.test_loader) as progress_bar:
            for data, labels in progress_bar:
                data = data.reshape(data.size(0), -1)
                labels = labels.to(self.device)
                pred = self.model(data)
                loss = self.loss_func(pred, labels)
                y_pred.append(pred.cpu().numpy().argmax(axis=1))
                y_true.append(labels.cpu().numpy())
                losses.append(loss.item())
                progress_bar.set_postfix(loss=loss.item())
        y_pred = np.concatenate(y_pred, axis=0)
        y_true = np.concatenate(y_true, axis=0)

        test_loss = sum(losses) / len(self.test_loader)
        mif = f1_score(y_true, y_pred, average="micro")
        maf = f1_score(y_true, y_pred, average="macro")
        print(f"test loss: {test_loss:.4f}, MiF: {mif:.4f}, MaF: {maf:.4f}")
        self.tsb_logger.add_scalars("test metrics", {"test loss": test_loss, "MiF": mif, "MaF": maf}, self.global_time_step)
        self.logger.info(f"test loss: {test_loss:.4f}, MiF: {mif:.4f}, MaF: {maf:.4f}")

        return test_loss

    def save_model(self, file_name):
        torch.save({
            "model": self.model.state_dict(),
            "optimizer": self.opt.state_dict(),
            "lr_scheduler": self.lr_scheduler.state_dict(),
            "global_time_step": self.global_time_step,

        }, self.checkpoint_dir / file_name)
        
    def load_model(self, file_name):
        status = torch.load(self.checkpoint_dir / file_name)
        self.model.load_state_dict(status["model"])
        self.opt.load_state_dict(status["optimizer"])
        self.lr_scheduler.load_state_dict(status["lr_scheduler"])
        self.global_time_step = status["global_time_step"]
        self.model.train()
        

    def train_session(self, start_epoch=0):
        for epoch in range(start_epoch, self.epochs):
            with tqdm(self.train_loader) as progress_bar:
                for data, labels in progress_bar:
                    self.logger.debug(data.shape)
                    data = data.reshape(data.size(0), -1)
                    labels = labels.to(self.device)
                    pred = self.model(data)
                    loss = self.loss_func(pred, labels)
                    loss.backward()
                    self.opt.step()
                    progress_bar.set_description(desc=f"Epoch: {epoch}")
                    loss_value = loss.item()
                    progress_bar.set_postfix(loss=loss_value)
                    self.global_time_step += 1
                    self.tsb_logger.add_scalar("train loss", loss_value, self.global_time_step)
                    self.logger.info(f"Epoch: {epoch} Step: {self.global_time_step} Loss: {loss_value:.4f}")

            test_loss = self.test()
            if self.lr_scheduler:
                self.lr_scheduler.step(test_loss)

def main():
    config = {"device": "cuda:2"}
    trainer = Trainer(**config)
    trainer.train_session()

if __name__ == "__main__":
    main()
