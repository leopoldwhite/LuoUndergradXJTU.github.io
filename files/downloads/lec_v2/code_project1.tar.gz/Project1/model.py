import torch
import torch.nn as nn
import numpy as np

class two_layer_mlp_classifier(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_classes = num_classes
        self.mlp1 = nn.Linear(input_dim, hidden_dim)
        self.mlp2 = nn.Linear(hidden_dim, num_classes)
        self.activation = torch.sigmoid
        
    def forward(self, x):
        return self.mlp2(self.activation(self.mlp1(x)))
