import torch
from torch import nn
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader
import json
########################################################
# your additional imports here



########################################################

def get_metrics(pred, truth):
    correct = 0
    for i in range(len(pred)):
        if torch.argmax(pred[i]) == truth[i]:
            correct += 1
    return correct / len(pred)

class BotDataset(Dataset):
    def __init__(self, name):  # name = train/dev
        path = 'Twibot-20/'

        self.name = name
        self.user_features = [] #TBD
        self.labels = [] #TBD
        self.length = 0 #TBD

        if self.name == 'train':
            f = open(path + 'train.json')
        if self.name == 'dev':
            f = open(path + 'dev.json')
        if self.name == 'test':
            f = open(path + 'test.json')

        users = json.load(f)
        for user in users:
            feature = []
            ########################################################
            # what features are important in your mind?
            feature.append(int(user['profile']['followers_count']))
            feature.append(int(user['profile']['friends_count']))
            feature.append(int(user['profile']['listed_count']))
            feature.append(int(user['profile']['favourites_count']))
            feature.append(int(user['profile']['statuses_count']))
            ########################################################
            self.user_features.append(torch.tensor(feature).float())
            self.labels.append(int(user['label']))
        self.user_features = torch.stack(self.user_features)
        self.user_features = (self.user_features - torch.mean(self.user_features, dim=0)) / torch.std(self.user_features, dim = 0)
        self.labels = torch.tensor(self.labels).long()
        self.length = len(users)

    def __len__(self):
        return self.length

    def __getitem__(self, index):
        return {'user_feature': self.user_features[index], 'label': self.labels[index]}


class BotDetector(pl.LightningModule):
    def __init__(self, num_features, hidden_dim):
        super().__init__()
        self.num_features = num_features
        self.hidden_dim = hidden_dim
        ########################################################
        # your model design
        # ideas to try out: Leaky Relu, Kaiming weight init, more layers and larger hidden dim, ...
        self.linear = nn.Linear(self.num_features, self.hidden_dim) #hidden layer
        self.out = nn.Linear(self.hidden_dim, 2) #output layer
        self.activation = nn.ReLU() #activation function
        self.CELoss = nn.CrossEntropyLoss() #loss function
        ########################################################

    def test_step(self, test_batch, batch_idx):

        user_features = test_batch['user_feature']
        labels = test_batch['label']

        ########################################################
        # your forward pass, identical to the train one
        user_features = self.activation(self.linear(user_features))
        user_features = self.out(user_features)  # DO NOT use activation on the output layer, output should always be batch_size * 2
        ########################################################

        accuracy = get_metrics(user_features, labels)
        print('Your best accuracy on the test set is: ' + str(accuracy) + ' !')
        return user_features

    def configure_optimizers(self):
        ########################################################
        # your optimizer design
        # ideas to try out: learning rate, weight decay, SGD optimizer (with momentum), ...
        optimizer = torch.optim.Adam(self.parameters())
        ########################################################
        return optimizer

    def training_step(self, train_batch, batch_idx):

        user_features = train_batch['user_feature']
        labels = train_batch['label']

        ########################################################
        # your forward pass
        # ideas to try out: dropout, ...
        user_features = self.activation(self.linear(user_features))
        user_features = self.out(user_features) # DO NOT use activation on the output layer, output should always be batch_size * 2
        ########################################################

        loss = self.CELoss(user_features, labels)
        accuracy = get_metrics(user_features, labels)
        self.log('train_loss', loss.item())
        self.log('train_accuracy', accuracy)
        return loss


    def validation_step(self, val_batch, batch_idx):

        user_features = val_batch['user_feature']
        labels = val_batch['label']

        ########################################################
        # your forward pass, identical with the train one
        user_features = self.activation(self.linear(user_features))
        user_features = self.out(user_features)  # DO NOT use activation on the output layer, output should always be batch_size * 2
        ########################################################

        loss = self.CELoss(user_features, labels)
        accuracy = get_metrics(user_features, labels)
        self.log('val_loss', loss.item())
        self.log('val_accuracy', accuracy)

########################################################
# hyperparameters, you can tune them
BATCH_SIZE = 64
NUM_FEATURES = 5
HIDDEN_DIM = 10
MAX_EPOCHS = 100
########################################################


train_dataset = BotDataset(name='train')
dev_dataset = BotDataset(name='dev')
test_dataset = BotDataset(name='test')

train_loader = DataLoader(train_dataset, batch_size = BATCH_SIZE)
dev_loader = DataLoader(dev_dataset, batch_size = BATCH_SIZE)
test_loader = DataLoader(test_dataset, batch_size = test_dataset.length)

# model
model = BotDetector(num_features = NUM_FEATURES, hidden_dim = HIDDEN_DIM)

# training
trainer = pl.Trainer(gpus=0, num_nodes=1, max_epochs = MAX_EPOCHS)
trainer.fit(model, train_loader, dev_loader)
trainer.test(model, test_dataloaders=test_loader, verbose=False)
