# Lecture 1: Deep Learning Basics

Welcome! Lecture 1 is a quick start guide to deep learning produced by LUD. Before getting started, **please construct your development environment according to requirements.txt**.

## Descriptions

* Lecture 1.pdf : slides

* lec1.ipynb: a simple start guide to pytorch
* template.py: code & homework
* requirements.txt: prerequisites for template.py & lec1.ipynb
* Dataset: please contact wind_binteng@stu.xjtu.edu.cn to obtain the Twibot-20 dataset

## Contact

If you have any advise or issue, feel free to contact tanzhaoxuan@stu.xjtu.edu.cn